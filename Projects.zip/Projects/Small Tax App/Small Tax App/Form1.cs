﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Small_Tax_App
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int salary;
            int age;
            double deduction;
            int relief;
            int totalSalary;
            salary = int.Parse(textBox1.Text);
            age = int.Parse(textBox2.Text);

            if (salary <= 5000)
            {
                if (age < 50)
                {
                    deduction = 0;
                    relief =2000;
                }
                else 
                {
                    deduction = 0;
                    relief = 5000;
                }
            }
            if (salary <= 10000)
            {
                if (age < 50)
                {
                    deduction = 0.05;
                    relief = 2000;
                }
                else
                {
                    deduction = 0.05;
                    relief = 5000;
                }
            }
            if (salary <= 20000)
            {
                if (age < 50)
                {
                    deduction = 0.075;
                    relief = 2000;
                }
                else
                {
                    deduction = 0.075;
                    relief = 5000;
                }
            }
            if (salary <= 35000)
            {
                if (age < 50)
                {
                    deduction = 0.09;
                    relief = 2000;
                }
                else
                {
                    deduction = 0.09;
                    relief = 5000;
                }
            }
            if (salary <= 50000)
            {
                if (age < 50)
                {
                    deduction = 0.15;
                    relief = 2000;
                }
                else
                {
                    deduction = 0.15;
                    relief = 5000;
                }
            }
            if (salary <= 70000)
            {
                if (age < 50)
                {
                    deduction = 0.25;
                    relief = 2000;
                }
                else
                {
                    deduction = 0.25;
                    relief = 5000;
                }
            }
            else 
            {
                if (age < 50)
                {
                    deduction = 0.3;
                    relief = 2000;
                }
                else
                {
                    deduction = 0.3;
                    relief = 5000;
                }
            }

            totalSalary = (int)((salary / deduction) + relief);

            MessageBox.Show("Tax to pay per annum :"+"R"+totalSalary);


        }
    }
}
