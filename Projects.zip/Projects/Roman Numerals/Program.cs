﻿// See https://aka.ms/new-console-template for more information

 static string numToRoman(int num) 
{
    string romanNum = "";

    Dictionary<string, int> romanNumberDictionary = new() 
    {
        { "I",1},
        { "IV",4},
        { "v", 5 },
        { "IX", 9 },
        { "x", 10 },
        { "XL", 40 },
        { "L", 50 },
        { "XC", 90 },
        { "C", 100 },
        { "CD", 400 },
        { "D", 500 },
        { "CM", 900 },
        { "M", 1000 },

    };

    foreach (var roman in romanNumberDictionary.Reverse()) 
    {
        if (num <= 0) break;

        while (num >= roman.Value) 
        {
            romanNum += roman.Key;
            num -= roman.Value;
        }
    }

    return romanNum;
}

int number = 1000;

for (int i = 0; i < number; i++)
{
    Console.WriteLine(numToRoman(i));

}













