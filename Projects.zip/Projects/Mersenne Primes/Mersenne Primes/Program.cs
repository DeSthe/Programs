﻿// See https://aka.ms/new-console-template for more information

int num, i,crt, startNumber, endNumber,  mersennePrimeNum = 0;


////input process

Console.WriteLine("Enter starting Number: ");
startNumber = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Enter ending Number: ");
endNumber = Convert.ToInt32(Console.ReadLine());

//process of getting prime numbers
primeNumber();


void primeNumber()
{
    for (num = startNumber; num <= endNumber; num++)
    {
        crt = 0;

        for (i = 2; i <= num / 2; i++)
        {
            if (num % i == 0)
            {
                crt++;
                break;
            }
        }

        if (crt == 0 && num != 1)
        {
            mersenneNumbers(num);

        }
    }

}


void mersenneNumbers(int n)
{
    int power = 0;
    int k = 0;

    if (n > 2)
    {
        while (power <= n + 1)
        {
            power = (int)Math.Pow(2, k);

            if (power == n + 1)
            {
               
                Console.WriteLine(n);

                return;
            }
            k++;
        }
    }
}





